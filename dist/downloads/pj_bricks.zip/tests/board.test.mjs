import test from 'node:test';
import assert from 'node:assert/strict';

import {
  ROWS,
  COLS,
  applyShift,
  cloneBoard,
  createBoard,
  createShiftChain,
  createShiftRevertMoves,
  findTargets,
  getShiftChainPositions,
  hasLineEmptyCell,
  hasAnySolvablePair,
  hasAnySolvablePairDeep,
  findSolvablePair,
  findSolvablePairDeep,
  reshuffleInPlace,
} from '../dist/game/board.js';
import { createSeededRng } from '../dist/game/levels.js';

function emptyBoard() {
  return Array.from({ length: ROWS }, () => Array(COLS).fill(null));
}

test('parameterized board uses every enabled icon in even counts', () => {
  const result = createBoard({
    iconIndices: Array.from({ length: 17 }, (_, i) => i),
    rng: createSeededRng(123),
  });

  assert.equal(result.ok, true);
  assert.equal(result.board.length, ROWS);
  assert.equal(result.board.flat().length, ROWS * COLS);
  const counts = new Map();
  result.board.flat().forEach(value => counts.set(value, (counts.get(value) || 0) + 1));
  assert.equal(counts.size, 17);
  assert.equal([...counts.values()].every(count => count >= 2 && count % 2 === 0), true);
  assert.ok(Math.max(...counts.values()) - Math.min(...counts.values()) <= 2);
});

test('same seed creates the same solvable board', () => {
  const iconIndices = Array.from({ length: 20 }, (_, i) => i);
  const left = createBoard({ iconIndices, rng: createSeededRng(456) });
  const right = createBoard({ iconIndices, rng: createSeededRng(456) });

  assert.deepEqual(left, right);
  assert.equal(hasAnySolvablePair(left.board), true);
});

test('different seeds can create different boards', () => {
  const iconIndices = Array.from({ length: 20 }, (_, i) => i);
  const left = createBoard({ iconIndices, rng: createSeededRng(456) });
  const right = createBoard({ iconIndices, rng: createSeededRng(789) });

  assert.notDeepEqual(left.board, right.board);
});

test('generation reports exhaustion', () => {
  const result = createBoard({ iconIndices: [0, 1], rng: () => 0, maxAttempts: 0 });
  assert.deepEqual(result, { ok: false, reason: 'no-solvable-pair' });
});

test('failed reshuffle restores the exact board', () => {
  const board = emptyBoard();
  board[0][0] = 1;
  board[13][9] = 2;
  const before = cloneBoard(board);

  const result = reshuffleInPlace(board, () => 0, { maxAttempts: 2 });

  assert.deepEqual(result, { ok: false, reason: 'no-solvable-pair' });
  assert.deepEqual(board, before);
});

test('fixed-chain positions follow the selected member and initial direction', () => {
  assert.deepEqual(getShiftChainPositions(6, 2, { axis: 'col', dir: -1, length: 4 }), [
    { r: 6, c: 2 },
    { r: 5, c: 2 },
    { r: 4, c: 2 },
    { r: 3, c: 2 },
  ]);
});

test('a fixed connected column can be pushed into empty cells above it', () => {
  const board = emptyBoard();
  board[3][0] = 1;
  board[4][0] = 2;
  board[5][0] = 3;
  board[6][0] = 4;
  const chain = createShiftChain(board, 6, 0, 'col', -1);

  const result = applyShift(board, 6, 0, chain, -3);

  assert.deepEqual(chain, { axis: 'col', dir: -1, length: 4 });
  assert.equal(result.applied, -3);
  assert.equal(result.moves.length, 4);
  assert.deepEqual(board.slice(0, 4).map(row => row[0]), [1, 2, 3, 4]);
  assert.deepEqual(board.slice(4, 7).map(row => row[0]), [null, null, null]);
});

test('a fixed row chain moves together through available empty cells', () => {
  const board = emptyBoard();
  board[2][1] = 1;
  board[2][2] = 2;
  board[2][3] = 3;
  const chain = createShiftChain(board, 2, 1, 'row', 1);

  const result = applyShift(board, 2, 1, chain, 2);

  assert.equal(result.applied, 2);
  assert.deepEqual(board[2].slice(1, 6), [null, null, 1, 2, 3]);
});

test('a fixed chain stops before an element outside the original chain', () => {
  const board = emptyBoard();
  board[1][0] = 1;
  board[1][1] = 2;
  board[1][5] = 9;
  const chain = createShiftChain(board, 1, 0, 'row', 1);

  const result = applyShift(board, 1, 0, chain, 8);

  assert.equal(result.applied, 3);
  assert.deepEqual(board[1].slice(0, 6), [null, null, null, 1, 2, 9]);
});

test('a fixed chain does not absorb a new element reached later in the drag', () => {
  const board = emptyBoard();
  board[1][0] = 1;
  board[1][3] = 9;
  const chain = createShiftChain(board, 1, 0, 'row', 1);

  const first = applyShift(board, 1, 0, chain, 2);
  const second = applyShift(board, 1, 2, chain, 1);

  assert.equal(first.applied, 2);
  assert.deepEqual(second, { applied: 0, moves: [] });
  assert.deepEqual(board[1].slice(0, 4), [null, null, 1, 9]);
});

test('chain rollback animates every member from final position to origin', () => {
  const chain = { axis: 'col', dir: -1, length: 3 };

  assert.deepEqual(createShiftRevertMoves(5, 2, 3, 2, chain), [
    { fromR: 3, fromC: 2, toR: 5, toC: 2 },
    { fromR: 2, fromC: 2, toR: 4, toC: 2 },
    { fromR: 1, fromC: 2, toR: 3, toC: 2 },
  ]);
});

test('moving the selected member can expose every legal target', () => {
  const board = emptyBoard();
  board[0][0] = 7;
  board[0][1] = 7;
  board[0][4] = 7;
  const chain = createShiftChain(board, 0, 1, 'row', 1);

  applyShift(board, 0, 1, chain, 1);

  assert.deepEqual(findTargets(board, 0, 2), [
    { r: 0, c: 0 },
    { r: 0, c: 4 },
  ]);
});

test('hasLineEmptyCell detects empty cells along the drag axis', () => {
  // 满盘整行无空格
  const full = Array.from({ length: ROWS }, () => Array.from({ length: COLS }, () => 0));
  assert.equal(hasLineEmptyCell(full, 5, 5, 'row'), false);
  assert.equal(hasLineEmptyCell(full, 5, 5, 'col'), false);

  // 行内存在空格
  full[5][9] = null;
  assert.equal(hasLineEmptyCell(full, 5, 0, 'row'), true);
  assert.equal(hasLineEmptyCell(full, 0, 5, 'col'), false);
});

test('applyShift never moves a chain on a board line without empties', () => {
  const full = Array.from({ length: ROWS }, () => Array.from({ length: COLS }, () => 0));
  const chain = createShiftChain(full, 5, 4, 'row', 1);
  const result = applyShift(full, 5, 4, chain, 2);
  assert.deepEqual(result, { applied: 0, moves: [] });
});

// ---- 深度死局检测（考虑拖拽可达解）----

function deepEmptyBoard() {
  return Array.from({ length: ROWS }, () => Array(COLS).fill(null));
}

test('IMG_2908 four-piece endgame is solvable by dragging bottom corn upward', () => {
  const b = deepEmptyBoard();
  b[4][9] = 2; b[13][9] = 2; // tomatoes blocked by corn
  b[5][9] = 3; b[13][6] = 3; // corn
  const before = cloneBoard(b);
  assert.equal(findSolvablePair(b), null);
  const chain = createShiftChain(b, 13, 6, 'col', -1);
  const playable = cloneBoard(b);
  assert.equal(applyShift(playable, 13, 6, chain, -8).applied, -8);
  assert.deepEqual(findTargets(playable, 5, 6), [{ r: 5, c: 9 }]);
  assert.equal(hasAnySolvablePairDeep(b), true);
  const result = findSolvablePairDeep(b);
  assert.ok(result.pair);
  const {r,c,chain: foundChain,delta} = result.shiftFrom;
  const replay = cloneBoard(b);
  assert.equal(applyShift(replay,r,c,foundChain,delta).applied,delta);
  assert.ok(findTargets(replay,result.pair.r1,result.pair.c1).some(t => t.r===result.pair.r2 && t.c===result.pair.c2));
  assert.deepEqual(b,before);
});

test('sparse endgame search stays reflection-symmetric and returns playable grabbed-cell matches', () => {
  const rng = createSeededRng(2908);
  for (let n=0;n<100;n++) {
    const b=deepEmptyBoard();
    for(let i=0;i<12;i++) {
      let r,c;
      do { r=Math.floor(rng()*ROWS); c=Math.floor(rng()*COLS); } while(b[r][c]!==null);
      b[r][c]=Math.floor(i/2);
    }
    const before=cloneBoard(b), result=findSolvablePairDeep(b);
    assert.equal(hasAnySolvablePairDeep(b.map(row=>row.slice().reverse())),!!result.pair);
    assert.equal(hasAnySolvablePairDeep(b.slice().reverse()),!!result.pair);
    if(result.pair && !result.direct) {
      const {r,c,chain,delta}=result.shiftFrom, replay=cloneBoard(b);
      assert.equal(applyShift(replay,r,c,chain,delta).applied,delta);
      assert.deepEqual(replay,result.board);
      assert.ok(findTargets(replay,result.pair.r1,result.pair.c1).some(t=>t.r===result.pair.r2&&t.c===result.pair.c2));
    }
    assert.deepEqual(b,before);
  }
});

test('findSolvablePairDeep finds pair reachable by one shift', () => {
  // 无直接配对：两枚 A 被列 0 的其它棋子隔开；
  // 但第 1 行整行左移 1 格后，两枚 A 在行 1 上直连。
  const board = deepEmptyBoard();
  board[0][0] = 0;            // A(挡路)
  board[0][3] = 1;
  board[1][3] = 0;            // A
  board[1][5] = 0;            // A —— 与 board[1][3] 之间隔着 board[1][4]
  board[1][4] = 2;
  board[2][3] = 3;
  // 初始无直接配对
  assert.equal(findSolvablePair(board), null);
  const result = findSolvablePairDeep(board);
  assert.ok(result.pair, '拖拽可达解应被找到');
  assert.equal(result.direct, false);
  assert.ok(result.depth >= 1);
});

test('findSolvablePairDeep reports direct pair without search', () => {
  const board = deepEmptyBoard();
  board[0][0] = 5;
  board[0][2] = 5;
  const result = findSolvablePairDeep(board);
  assert.equal(result.direct, true);
  assert.equal(result.depth, 0);
  assert.equal(result.pair.r1, 0);
});

test('findSolvablePairDeep declares true deadlock (nothing reachable)', () => {
  const board = deepEmptyBoard();
  // 全盘仅 2 枚不同图标，永无可消对，且任何拖拽都无法改变这一点
  board[0][0] = 0;
  board[5][5] = 1;
  const result = findSolvablePairDeep(board);
  assert.equal(result.pair, null);
});

test('hasAnySolvablePairDeep mirrors findSolvablePairDeep', () => {
  const board = deepEmptyBoard();
  board[0][0] = 0;
  board[3][2] = 0;
  board[3][4] = 1;
  board[0][9] = 1;
  assert.equal(hasAnySolvablePair(board), false);
  assert.equal(hasAnySolvablePairDeep(board), true);
});

// 回归：screenshot4/用户日志盘面——解需把行首对子整排拖 8 格。
// 旧的逐格 BFS 在 6000 节点内到不了第 8 层而误判死局；宏移动搜索第 1 层即命中
test('deep search finds pair-aligned-by-8-shift solution (user report regression)', () => {
  const b = deepEmptyBoard();
  b[0][0] = 15; b[0][1] = 4; b[11][9] = 4; b[12][9] = 15;
  const result = findSolvablePairDeep(b);
  assert.equal(result.direct, false);
  assert.ok(result.pair, `expected solvable, got ${JSON.stringify(result)}`);
  assert.equal(hasAnySolvablePairDeep(b), true);
});

// 宏移动与单步等价性抽查：单步可达的最浅解深度（按格计）大于宏深度
test('macro search depth reflects segment slides, not cell steps', () => {
  const b = deepEmptyBoard();
  // 3@(0,0) 需整排滑 9 格到 (0,9) 才与 3@(12,9) 同列直连：宏深度应为 1
  b[0][0] = 3; b[12][9] = 3;
  const result = findSolvablePairDeep(b);
  assert.ok(result.pair, `expected solvable, got ${JSON.stringify(result)}`);
  assert.equal(result.depth, 1);
});

test('true deadlock with two distinct far pieces still detected', () => {
  const b = deepEmptyBoard();
  b[0][0] = 5; b[13][9] = 9;
  assert.equal(hasAnySolvablePairDeep(b), false);
  const result = findSolvablePairDeep(b);
  assert.equal(result.pair, null);
});

// 全同图标双段：任意位置都直连/一步可达，必须判可解
test('same-icon segments always solvable via slide', () => {
  const b = deepEmptyBoard();
  b[0][0] = 2; b[5][5] = 2; b[9][9] = 2;
  assert.equal(hasAnySolvablePairDeep(b), true);
});

// 回归：screenshot6 用户实局盘面（8 对棋子）。旧"多步滑移"口径误判有解，
// 但拖拽规则是"无消除即还原"，多步中转不可达——真实判定应为死局。
// 且配对若不涉及被拖链上的棋子（消除目标必须属于被抓棋子），同样不算可达。
test('screenshot6 board is deadlock: solution needs two non-eliminating drags (user report regression)', () => {
  const b = deepEmptyBoard();
  // A:(0,0)(13,4) B:(0,6)(8,0) C:(0,8)(12,4) D:(0,9)(12,9)
  // E:(5,0)(11,9) F:(8,5)(12,0) G:(8,9)(13,5) H:(12,7)(13,0)
  b[0][0] = 1; b[13][4] = 1;
  b[0][6] = 2; b[8][0] = 2;
  b[0][8] = 3; b[12][4] = 3;
  b[0][9] = 4; b[12][9] = 4;
  b[5][0] = 5; b[11][9] = 5;
  b[8][5] = 6; b[12][0] = 6;
  b[8][9] = 7; b[13][5] = 7;
  b[12][7] = 8; b[13][0] = 8;
  assert.equal(hasAnySolvablePairDeep(b), false);
  const result = findSolvablePairDeep(b);
  assert.equal(result.pair, null);
});

// 拖拽后若只有"不涉及被拖链"的配对出现，不算可达（目标必须属于被抓棋子）
test('pair not involving dragged chain does not count as reachable', () => {
  const b = deepEmptyBoard();
  // 第 3 行拖走障碍后，第 0 行的两颗同色直连——但被拖的是第 3 行的链
  b[0][3] = 9; b[0][6] = 9;   // 中间 (0,4)(0,5) 空？不，让它们被占：
  b[0][4] = 10; b[0][5] = 11;
  // 第 3 行一段可拖入 (0,4)(0,5) 前方？构造：被拖链滑走后 (0,4)(0,5) 仍在，
  // 第 3 行移动与任何配对无关——只有第 0 行 (0,3)/(0,6) 隔着 (0,4)(0,5) 不直连。
  // 再放一颗与被拖链同排的同色，使链滑走时无自身配对：
  b[3][0] = 12; b[3][1] = 13; b[3][2] = 14; b[3][3] = 15; // 第 3 行段
  assert.equal(hasAnySolvablePairDeep(b), false);
});

test('progressive levels meet their opening budget and preserve balanced even counts across seeds', async () => {
  const {getLevelConfig} = await import('../dist/game/levels.js');
  const {countOpeningPairs} = await import('../dist/game/board.js');
  for(let level=1;level<=20;level++) for(let seed=1;seed<=25;seed++) {
    const config = getLevelConfig(level,{randomSeed:seed});
    const result = createBoard({iconIndices:config.iconIndices,rng:createSeededRng(config.seed),openingPairs:config.openingPairs});
    assert.equal(result.ok,true,`level ${level} seed ${seed}`);
    const pairs = countOpeningPairs(result.board);
    assert.ok(pairs>=config.openingPairs.min && pairs<=config.openingPairs.max);
    assert.equal(hasAnySolvablePair(result.board),true);
    const counts = new Map();
    result.board.flat().forEach(v=>counts.set(v,(counts.get(v)||0)+1));
    assert.equal(counts.size,config.iconCount);
    assert.ok([...counts.values()].every(n=>n%2===0));
    assert.ok(Math.max(...counts.values())-Math.min(...counts.values())<=2);
  }
});

test('difficulty tuning remains deterministic on restart and rejects zero-opening budgets', async () => {
  const options = {iconIndices:Array.from({length:20},(_,i)=>i),openingPairs:{min:1,max:1}};
  assert.deepEqual(createBoard({...options,rng:createSeededRng(9123)}),createBoard({...options,rng:createSeededRng(9123)}));
  assert.throws(()=>createBoard({...options,openingPairs:{min:0,max:0}}),RangeError);
});
