# Task 6 Report: interaction.js 实现

## 状态
✅ 完成

## Commits
- `e54c718` - feat: interaction state, render, click logic with busy lifecycle and hint timing

## 验证（静态检查）

### 1. 导出检查
- ✅ 仅导出 `initGame` 函数（line 305）
- ✅ 其他函数均为内部模块私有

### 2. 状态字段声明
```js
const state = {
  board: null,
  cellEls: [],
  busy: false,
  mode: 'idle',
  anchor: null,
  candidates: [],
  pendingRevert: null,
  pitch: 35,
  round: 1,
  deadlockCount: 0,
  drag: null,
  hintTimer: null,
};
```
✅ 所有 12 个字段均已声明

### 3. setBusy 调用点
- `setBusy(true)` line 232 - afterEliminate 胜利时
- `setBusy(true)` line 251 - handleDeadlock 进入时
- `setBusy(false)` line 259 - handleDeadlock reshuffle 分支
- `setBusy(false)` line 278 - restart 结束时
✅ busy 生命周期正确设置（A1 修复）

### 4. deadlockCount 状态机
- `state.deadlockCount++` line 255 - 首次死局选择 reshuffle
- `state.deadlockCount = 0` line 272 - restart 重置
✅ 死局计数状态机正确

### 5. 震惊脸动画时序
- `withFace(svg.outerHTML, 'shock')` line 173
- `setTimeout(..., 180)` line 175 - 180ms 后清除
✅ 符合 A8 表情动画要求

### 6. 单目标 220ms 学习窗口
- `setTimeout(..., 220)` line 141 - 单目标延迟消除
✅ 符合 A8 学习窗口要求

### 7. Hint 2s 定时器
- `setTimeout(..., 2000)` line 228 - hint 高亮 2 秒后移除
✅ 符合要求

## 自评

### 实现完整性
- ✅ 状态对象：12 个字段全部声明
- ✅ 渲染系统：renderBoard + syncDOM
- ✅ 点击交互：onCellClick + selectAndEvaluate + eliminate + cancelSelection
- ✅ 模式转换：idle → selected（单目标 220ms）→ waiting（多目标）
- ✅ Hint 系统：2s 高亮定时器
- ✅ 死局处理：状态机（首次弹框，二次游戏结束）
- ✅ 胜利检测：showWin + onRestart 回调
- ✅ 重开逻辑：restart 重置所有状态
- ✅ busy 生命周期：修复 A1（setBusy 实际调用）
- ✅ 占位函数：onPointerDown/Move/Up、animateMoves

### 关键修复
- **A1**: busy 现在正确设置为 true/false，阻塞所有异步窗口期间的输入
- **A8**: 单目标 220ms 学习窗口 + hint 2s 高亮不被自动消除吞掉

### 代码质量
- 模块化设计清晰，状态私有化
- 纯函数与 DOM 操作分离
- 事件代理绑定正确
- 定时器清理逻辑完整（tipTimer、hintTimer）

### 占位说明
- `rollbackPending` 调用 `animateMoves(revertMoves, 180)` 但 Task 7 未填充，目前 animateMoves 为空函数
- Task 7 接管后拖拽逻辑将设置 pendingRevert，rollbackPending 才有实际效果
- 当前阶段 rollbackPending 仅清除 pendingRevert 状态，不影响其他功能

## 关切点

无重大关切。实现与简报一致，静态检查全部通过。

### 次要观察
1. 点击事件代理已绑定 pointer 事件，但 Task 7 填充前无实际响应
2. animateMoves 占位函数被调用（rollbackPending），但无副作用，不影响当前功能
3. Tip 清理机制使用独立 tipTimer，与 hintTimer 分离，逻辑清晰

## 评审反馈修复

### Critical Fix 1: 220ms 学习窗口竞态条件
**问题**: 单目标点击触发 `setTimeout(..., 220)` 时，`state.busy` 未设置，用户可在 220ms 期间再次点击导致状态混乱。

**修复**:
- `selectAndEvaluate` 单目标分支：在 `setTimeout` 前调用 `setBusy(true)`
- `setTimeout` 回调末尾：无论是否消除都调用 `setBusy(false)`
- 回调内部增加 anchor 校验：`state.anchor && state.anchor.r === r && state.anchor.c === c`
  - 若用户在 220ms 期间操作，`cancelSelection` 会清空 anchor，自动取消消除

**修复后路径**:
```js
setBusy(true);
setTimeout(() => {
  if (state.anchor && state.anchor.r === r && state.anchor.c === c) {
    eliminate(...);
  }
  setBusy(false);
}, 220);
```

### Critical Fix 2: 胜利弹框关闭后 busy=true 永久
**问题**: `showWin()` 返回 `{close, onRestart}`，用户点击 × 关闭（非重启）时，`onRestart` 不触发，`afterEliminate` 中的 `setBusy(true)` 永不解除。

**修复**:
1. **dialogs.js**: `showWin()` 增加 `onClose` 回调参数，在 × 按钮点击时触发
2. **interaction.js**: `afterEliminate` 胜利分支传递 `onClose: () => setBusy(false)`

**修复后代码**:
```js
// dialogs.js
export function showWin({ onClose } = {}) {
  // ...
  const handleClose = () => { close(); onClose && onClose(); };
  closeBtn.addEventListener('click', handleClose, { once: true });
  return { close: handleClose, onRestart: (cb) => listeners.push(cb) };
}

// interaction.js
if (isAllCleared()) {
  setBusy(true);
  const w = showWin({ onClose: () => setBusy(false) });
  w.onRestart(() => { restart(); });
  return;
}
```

### 验证（修复后静态检查）
```bash
$ grep -n "setBusy" game/interaction.js
32:  function setBusy(v) { state.busy = v; }
137:  setBusy(true);  // 单目标 220ms 窗口开始
142:  setBusy(false); // 单目标 220ms 窗口结束
234:  setBusy(true);  // 胜利弹框显示
235:  const w = showWin({ onClose: () => setBusy(false) }); // 胜利弹框关闭
253:  setBusy(true);  // 死局处理开始
261:  setBusy(false); // 死局 reshuffle 分支
280:  setBusy(false);  // restart 结束
```

✅ 所有 `setBusy(true)` 都有对应的 `setBusy(false)`，busy 生命周期完整平衡。
