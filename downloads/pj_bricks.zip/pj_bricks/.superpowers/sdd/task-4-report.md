# Task 4 Report: board.js 纯函数实现

## Status
✅ **完成** - 实现了所有必需的纯棋盘函数，并通过 Node.js 测试验证。

## Commits
- `4ecbd31` - feat: pure board logic module with create/clear/find/reshuffle/shift

## Verification
使用 Node.js 测试套件验证（无法使用浏览器，改用 file:// URL 导入）：

```
=== Testing board.js ===

Constants:
✓ ROWS should be 14
✓ COLS should be 10
✓ KINDS should be 14
✓ PER_KIND should be 10

createBoard:
✓ createBoard should return a board
✓ board should have ROWS rows
✓ each row should have COLS columns
✓ createBoard must be solvable

isClearPath:
✓ clear path on same row (no obstacles)
✓ blocked path on same row
✓ blocked path on same column (has obstacles)
✓ non-aligned cells should return false

findTargets:
  targets from (5,5): [{"r":7,"c":5},{"r":5,"c":3},{"r":5,"c":7}]
✓ should find at least 2 targets

findSolvablePair:
✓ should find a solvable pair
✓ should find the correct solvable pair

cloneBoard:
✓ clone should be deep copy (original unaffected)

restoreBoard:
✓ restoreBoard should restore state

applyShift:
  shift result: {"applied":2,"moves":[{"fromR":5,"fromC":4,"toR":5,"toC":6},{"fromR":5,"fromC":3,"toR":5,"toC":5}]
✓ shift should be applied
✓ shift should generate moves
✓ pieces should have moved

reshuffleInPlace:
✓ reshuffle should change the board
✓ reshuffled board should still be solvable

=== Test Summary ===
Passed: 22
Failed: 0
ALL TESTS PASSED
```

## Self-review

### 实现要点
1. **常量定义**：ROWS=14, COLS=10, KINDS=14, PER_KIND=10，共140格
2. **createBoard**：使用 Fisher-Yates 洗牌算法，保证1000次尝试内必可解
3. **isClearPath**：0折直线连通检测，同行或同列无阻挡
4. **findTargets**：四方向扫描首个同图案目标
5. **findSolvablePair**：暴力搜索所有同图案对，检查是否可直线连通
6. **reshuffleInPlace**：就地洗牌，保证1000次尝试内必可解
7. **applyShift**：关键实现，注意循环方向避免覆盖：
   - 向高索引移动时，从远端开始搬
   - 向低索引移动时，从近端开始搬
8. **cloneBoard/restoreBoard**：深拷贝和状态恢复

### 关键细节
- applyShift 的循环迭代方向严格按照 brief 要求实现
- doMove 函数内部使用 `for (let x = dir > 0 ? hi : lo; dir > 0 ? x >= lo : x <= hi; x += dir > 0 ? -1 : 1)` 确保正确搬运顺序
- 所有函数均为纯函数或就地操作，无 DOM 依赖

## Concerns
无明显问题。所有测试通过，实现符合 brief 要求。

## 文件变更
- **创建**：`game/board.js` (205行)
- **修改**：无（覆盖原有空文件）

## Fix Report

### Bug Fixed
- **Line 188**: `doMove(c, hi, false, +1)` → `doMove(r, hi, false, +1)`
  - 修复：列轴正向平移时，第一个参数应为行索引 `r`（沿移动轴的 lo 索引），而非列索引 `c`
  - 原因：`doMove(lo, hi, axisIsRow, dir)` 的 `lo` 参数是沿移动轴的低索引，列轴移动时是行索引
- **Line 136**: 删除了未使用的 `const len = hi - lo + 1;` 变量

### Verification
```bash
$ node /tmp/test-shift-fix.mjs
PASS: column positive shift correct
```

### Test Coverage
- 验证所有移动棋子的 `toR === fromR + 1 && fromC === toC`（列轴正向位移）
- 验证棋子总数不变（`before === after`）
