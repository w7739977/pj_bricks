### Task 1: 文件脚手架 + server.js 静态路由

**Files:**
- Create: `styles.css`（空占位 + 1 行注释）
- Create: `game/main.js`、`game/board.js`、`game/svg-icons.js`、`game/dialogs.js`、`game/interaction.js`（每个文件仅 `// placeholder` + 空 export）
- Modify: `index.html`（删除原 IIFE，替换为 module 入口；保留 body 结构；加 fonts）
- Modify: `server.js`（增加 MIME 路由）

**Interfaces:**
- Produces: `server.js` 监听 3013；`/`、`/styles.css`、`/game/*.js`、`/favicon.ico` 均返回正确 MIME
- Produces: `index.html` 中 `<script type="module" src="/game/main.js"></script>`

- [ ] **Step 1: 替换 `server.js`**

完整内容写入 `server.js`：

```js
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3013;
const ROOT = __dirname;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.woff2': 'font/woff2',
};

const server = http.createServer((req, res) => {
  // 安全：禁止路径穿越
  const url = decodeURIComponent(req.url.split('?')[0]);
  if (url.includes('..')) { res.writeHead(400); res.end('Bad Request'); return; }

  let filePath = url === '/' ? '/index.html' : url;
  const full = path.join(ROOT, filePath);
  if (!full.startsWith(ROOT)) { res.writeHead(403); res.end('Forbidden'); return; }

  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not Found'); return; }
    const ext = path.extname(full).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log(`pj_bricks game running at http://localhost:${PORT}`);
});
```

- [ ] **Step 2: 替换 `index.html` 结构（保留 body，删 IIFE，加字体 + module）**

完整内容写入 `index.html`：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>田园连连看</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&family=ZCOOL+KuaiLe&family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/styles.css">
</head>
<body>
  <header class="topbar">
    <h1 class="title">田园连连看</h1>
    <div class="meta" id="meta">第 <span id="round">1</span> 局</div>
  </header>

  <p id="tip" class="tip" aria-live="polite"></p>

  <main class="board-wrap">
    <div id="board" class="board" role="grid" aria-label="连连看棋盘"></div>
  </main>

  <nav class="controls" aria-label="工具">
    <button class="tool tool--hint" id="hintBtn" type="button" aria-label="提示">💡 提示</button>
    <button class="tool tool--shuffle" id="shuffleBtn" type="button" aria-label="手动重排">🔀 重排</button>
    <button class="tool tool--restart" id="restartBtn" type="button" aria-label="重新开始">🔄 重开</button>
  </nav>

  <!-- 胜利弹框 -->
  <dialog id="winDialog" class="dialog dialog--win">
    <div class="dialog__card">
      <button class="dialog__close" data-close type="button" aria-label="关闭">✕</button>
      <h2 class="dialog__title">🎉 游戏胜利！</h2>
      <p class="dialog__desc">所有方块已消除完毕</p>
      <div class="dialog__actions">
        <button class="tool tool--primary" data-win-restart type="button">再来一局</button>
      </div>
    </div>
  </dialog>

  <!-- 死局弹框（首次） -->
  <dialog id="deadlockDialog" class="dialog dialog--deadlock">
    <div class="dialog__card">
      <h2 class="dialog__title">😵 陷入死局</h2>
      <p class="dialog__desc">当前盘面已无可消除对，要怎么处理？</p>
      <div class="dialog__actions">
        <button class="tool tool--secondary" data-deadlock-giveup type="button">🏳️ 放弃本局</button>
        <button class="tool tool--primary" data-deadlock-reshuffle type="button">🔀 重排一次</button>
      </div>
    </div>
  </dialog>

  <!-- 游戏结束弹框（二次及以后死局） -->
  <dialog id="gameOverDialog" class="dialog dialog--gameover">
    <div class="dialog__card">
      <h2 class="dialog__title">💔 游戏结束</h2>
      <p class="dialog__desc" id="gameOverDesc">本局共出现 2 次死局</p>
      <div class="dialog__actions">
        <button class="tool tool--primary" data-gameover-restart type="button">🏳️ 放弃本局并重开</button>
      </div>
    </div>
  </dialog>

  <script type="module" src="/game/main.js"></script>
</body>
</html>
```

- [ ] **Step 3: 创建空模块文件**

每个文件 1 行注释占位：
- `styles.css`：`/* Claymorphism 设计令牌 — Task 3 填充 */`
- `game/main.js`：`// 启动入口 — Task 11 填充`
- `game/board.js`：`// 纯棋盘函数 — Task 4 填充`
- `game/svg-icons.js`：`// 14 个漫画 SVG — Task 2 填充`
- `game/dialogs.js`：`// 弹框管理 — Task 5 填充`
- `game/interaction.js`：`// 状态与交互 — Task 7-10 填充`

- [ ] **Step 4: 启动服务器并验证路由**

Run: `node /home/ubuntu/pj_bricks/server.js &`
Run: `curl -sI http://localhost:3013/ | head -3` → 期望 `200` + `text/html`
Run: `curl -sI http://localhost:3013/styles.css | head -3` → 期望 `200` + `text/css`
Run: `curl -sI http://localhost:3013/game/main.js | head -3` → 期望 `200` + `application/javascript`
Run: `curl -sI http://localhost:3013/game/../server.js | head -3` → 期望 `403` 或 `400`
Run: `kill %1`

- [ ] **Step 5: Commit**

```bash
cd /home/ubuntu/pj_bricks
git init 2>/dev/null || true
git add -A
git commit -m "chore: scaffold multi-file structure and static server routes"
```

---

