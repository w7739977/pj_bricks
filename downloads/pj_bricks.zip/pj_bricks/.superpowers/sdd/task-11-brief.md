### Task 11: main.js — 启动入口 + 字体后备 + reduced-motion 全局

**Files:**
- Modify (overwrite placeholder): `game/main.js`

- [ ] **Step 1: 写 `game/main.js`**

```js
import { initGame } from './interaction.js';

// 等待 DOM 就绪
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initGame);
} else {
  initGame();
}

// 字体加载完成后重测 pitch（字体回流后单元格位置可能微调）
if (document.fonts && document.fonts.ready) {
  document.fonts.ready.then(() => window.dispatchEvent(new Event('resize')));
}

// reduced-motion 全局提示（CSS 已处理动画降级；JS 侧仅日志）
if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  console.info('[a11y] reduced-motion 已启用，动画已降级');
}
```

- [ ] **Step 2: 完整端到端冒烟**

```bash
node /home/ubuntu/pj_bricks/server.js &
```
浏览器打开 `http://localhost:3013/`，DevTools 无报错，依次：
1. 蔬菜全部漫画 SVG 渲染
2. 玩到自然胜利（或用 `__forceDeadlock` 验各弹框）
3. 拖拽、点击、提示、重排、重开各按钮均工作
4. 切 375/768/1440 三档视口无溢出
5. 系统设置开"减少动态效果"，所有动画降级为瞬切

- [ ] **Step 3: Commit**

```bash
git add game/main.js
git commit -m "feat: main entry with DOM-ready init and font reflow handling"
```

---

