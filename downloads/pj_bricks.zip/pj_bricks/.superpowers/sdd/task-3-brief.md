### Task 3: styles.css — Claymorphism 令牌 + 14×10 竖版响应式布局

**Files:**
- Create (overwrite): `styles.css`

**Interfaces:**
- Produces: CSS 变量 `--color-primary`、`--color-bg`、`--pitch`、`--radius-cell` 等
- Produces: `.board` 使用 CSS Grid `grid-template-columns: repeat(10, var(--pitch))` `grid-template-rows: repeat(14, var(--pitch))`
- Produces: `.cell` `aspect-ratio: 1`；`.cell.selected` 黄色 ring；`.cell.hint` 绿色 blink；`.cell.empty` 透明；`.cell.shake` 抖动
- Produces: `.dialog` + `.dialog__card` Claymorphism 卡片；`.dialog[open]` 入场动画；`::backdrop` 50% 黑 + 5px blur
- Produces: `@media (prefers-reduced-motion: reduce)` 关闭所有 transition/animation
- Produces: 响应式断点 `< 480`、`480–768`、`≥ 768` 调整 `--pitch`

- [ ] **Step 1: 写 `styles.css`**

完整文件：

```css
/* ===== Claymorphism 设计令牌 ===== */
:root {
  --color-primary: #EC4899;
  --color-on-primary: #FFFFFF;
  --color-secondary: #8B5CF6;
  --color-accent: #F59E0B;
  --color-bg: #FDF2F8;
  --color-fg: #0F172A;
  --color-muted: #FDF4F8;
  --color-border: #FCE9F2;
  --color-destructive: #DC2626;
  --color-ring: #EC4899;

  --radius-board: 32px;
  --radius-cell: 12px;
  --radius-button: 24px;

  --shadow-soft: 0 8px 24px rgba(139, 92, 246, 0.18);
  --shadow-clay: 0 12px 32px rgba(236, 72, 153, 0.22), inset 0 0 0 2px rgba(255,255,255,0.65);
  --shadow-press: 0 4px 12px rgba(236, 72, 153, 0.28);

  --pitch: 35px;  /* 移动端默认，断点处覆盖 */
  --font-title: 'ZCOOL KuaiLe', 'Noto Sans SC', sans-serif;
  --font-body: 'Baloo 2', 'Noto Sans SC', sans-serif;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
  min-height: 100dvh;
  font-family: var(--font-body);
  background:
    radial-gradient(circle at 15% 20%, rgba(236, 72, 153, 0.12), transparent 40%),
    radial-gradient(circle at 85% 80%, rgba(139, 92, 246, 0.12), transparent 40%),
    linear-gradient(160deg, #fdf2f8 0%, #fce7f3 50%, #f5d0fe 100%);
  color: var(--color-fg);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 12px;
  gap: 10px;
  overflow-x: hidden;
}

/* ===== 顶栏 ===== */
.topbar {
  width: 100%;
  max-width: 520px;
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  padding: 0 8px;
}
.title {
  font-family: var(--font-title);
  font-size: clamp(22px, 5vw, 32px);
  color: var(--color-primary);
  text-shadow: 1px 1px 0 #fff;
  letter-spacing: 2px;
}
.meta { font-size: 14px; color: var(--color-secondary); font-weight: 600; }
.meta #round { font-variant-numeric: tabular-nums; }

/* ===== 提示文字 ===== */
.tip {
  min-height: 22px;
  font-size: 14px;
  color: var(--color-destructive);
  font-weight: 600;
  text-align: center;
}

/* ===== 棋盘 ===== */
.board-wrap { width: 100%; display: flex; justify-content: center; }
.board {
  display: grid;
  grid-template-columns: repeat(10, var(--pitch));
  grid-template-rows: repeat(14, var(--pitch));
  gap: 3px;
  padding: 12px;
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(8px);
  border-radius: var(--radius-board);
  box-shadow: var(--shadow-clay);
}
.cell {
  width: var(--pitch);
  height: var(--pitch);
  background: #fff;
  border-radius: var(--radius-cell);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  user-select: none;
  -webkit-user-select: none;
  touch-action: none;
  box-shadow: var(--shadow-soft), inset 0 0 0 1px rgba(236, 72, 153, 0.08);
  transition: transform 0.15s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.15s;
}
.cell:hover { transform: translateY(-2px); }
.cell.selected {
  background: #fef3c7;
  box-shadow: 0 0 0 3px var(--color-accent), var(--shadow-soft);
  transform: translateY(-2px);
}
.cell.hint {
  animation: blink 0.5s ease-in-out infinite alternate;
}
@keyframes blink {
  from { box-shadow: 0 0 0 3px var(--color-primary), 0 0 10px rgba(236,72,153,0.6); background: #fce7f3; }
  to   { box-shadow: 0 0 0 3px #f472b6, 0 0 18px rgba(236,72,153,0.9); background: #fbcfe8; }
}
.cell.shake { animation: shake 0.55s cubic-bezier(0.36, 0.07, 0.19, 0.97) both; }
@keyframes shake {
  10%, 90%  { transform: translateX(-2px) rotate(-3deg); }
  20%, 80%  { transform: translateX(4px) rotate(5deg); }
  30%, 50%, 70% { transform: translateX(-6px) rotate(-7deg); }
  40%, 60%  { transform: translateX(6px) rotate(7deg); }
}
.cell.empty {
  background: transparent;
  box-shadow: none;
  cursor: default;
}
.cell.empty:hover { transform: none; }
.cell .veg { width: 78%; height: 78%; pointer-events: none; }

/* ===== 工具按钮 ===== */
.controls { display: flex; gap: 12px; flex-wrap: wrap; justify-content: center; }
.tool {
  font-family: var(--font-body);
  font-size: 15px;
  font-weight: 700;
  padding: 10px 20px;
  border: none;
  border-radius: var(--radius-button);
  cursor: pointer;
  color: var(--color-on-primary);
  background: linear-gradient(135deg, var(--color-secondary), var(--color-primary));
  box-shadow: 0 4px 12px rgba(139, 92, 246, 0.35);
  transition: transform 0.15s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.15s;
}
.tool:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(139,92,246,0.45); }
.tool:active { transform: scale(0.94); }
.tool--hint { background: linear-gradient(135deg, var(--color-accent), #d97706); }
.tool--shuffle { background: linear-gradient(135deg, #10b981, #047857); }
.tool--restart { background: linear-gradient(135deg, var(--color-secondary), #6d28d9); }
.tool--primary { background: linear-gradient(135deg, var(--color-primary), #be185d); }
.tool--secondary { background: linear-gradient(135deg, #94a3b8, #475569); }

/* ===== 弹框 ===== */
.dialog { padding: 0; border: none; background: transparent; max-width: 90vw; }
.dialog::backdrop { background: rgba(15, 23, 42, 0.5); backdrop-filter: blur(5px); }
.dialog[open] { animation: dialog-in 0.2s ease-out; }
.dialog[open]::backdrop { animation: backdrop-in 0.2s ease-out; }
@keyframes dialog-in {
  from { transform: scale(0.85); opacity: 0; }
  to   { transform: scale(1); opacity: 1; }
}
@keyframes backdrop-in { from { opacity: 0; } to { opacity: 1; } }
.dialog__card {
  position: relative;
  background: #fff;
  padding: 32px 36px 24px;
  border-radius: 28px;
  box-shadow: 0 20px 60px rgba(236, 72, 153, 0.35), inset 0 0 0 2px rgba(255,255,255,0.8);
  text-align: center;
  min-width: 280px;
}
.dialog__title { font-family: var(--font-title); font-size: 26px; color: var(--color-primary); margin-bottom: 8px; }
.dialog__desc { font-size: 14px; color: #475569; margin-bottom: 20px; }
.dialog__actions { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.dialog__close {
  position: absolute; top: 12px; right: 12px;
  width: 32px; height: 32px;
  border: none; background: transparent;
  font-size: 16px; color: #94a3b8;
  cursor: pointer; border-radius: 50%;
}
.dialog__close:hover { background: #f1f5f9; color: #475569; }

/* ===== 响应式：根据视口调整 pitch ===== */
@media (min-width: 480px) { :root { --pitch: 40px; } }
@media (min-width: 768px) { :root { --pitch: 48px; } .board { gap: 4px; } }

/* ===== 降级：reduced motion ===== */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
  .cell:hover { transform: none; }
  .tool:hover { transform: none; }
}
```

- [ ] **Step 2: 浏览器手测**

`game/main.js` 临时写：
```js
const b = document.getElementById('board');
for (let i = 0; i < 140; i++) {
  const c = document.createElement('div');
  c.className = i % 7 === 0 ? 'cell empty' : 'cell';
  c.textContent = i;
  b.appendChild(c);
}
```
打开页面，确认：
- 棋盘是 10 列 14 行
- 375px / 768px / 1440px 三档无横向滚动
- 单元格圆角 + 柔光阴影
- 测一单元格实际中心距 → 控制台应接近 35/40/48（用于 Task 8 校验）
测后清空 main.js。

- [ ] **Step 3: Commit**

```bash
git add styles.css
git commit -m "feat: claymorphism design tokens and 14x10 vertical responsive board"
```

---

