### Task 5: dialogs.js — 死局 / 游戏结束 / 胜利弹框

**Files:**
- Create (overwrite): `game/dialogs.js`

**Interfaces:**
- Consumes: `index.html` 中已存在的 `<dialog id="winDialog">`、`<dialog id="deadlockDialog">`、`<dialog id="gameOverDialog">`
- Produces:
  - `export function showWin()` → 显示胜利弹框；返回 `{ close: () => void, onRestart: (cb) => void }`
  - `export function showDeadlock()` → 返回 `Promise<'reshuffle' | 'giveup'>`
  - `export function showGameOver(deadlockCount)` → 返回 `Promise<void>`（仅一个按钮，resolve 即放弃）

- [ ] **Step 1: 写 `game/dialogs.js`**

```js
// 弹框管理：基于原生 <dialog>。

const $ = (id) => document.getElementById(id);

export function showWin() {
  const dlg = $('winDialog');
  const card = dlg.querySelector('.dialog__card');
  dlg.showModal();
  const restartBtns = dlg.querySelectorAll('[data-win-restart]');
  const closeBtn = dlg.querySelector('[data-close]');
  const listeners = [];
  const close = () => { if (dlg.open) dlg.close(); };
  restartBtns.forEach(btn => btn.addEventListener('click', () => {
    close();
    listeners.forEach(cb => cb());
  }, { once: true }));
  closeBtn.addEventListener('click', close, { once: true });
  return {
    close,
    onRestart: (cb) => listeners.push(cb),
  };
}

export function showDeadlock() {
  return new Promise((resolve) => {
    const dlg = $('deadlockDialog');
    const reshuffleBtn = dlg.querySelector('[data-deadlock-reshuffle]');
    const giveupBtn = dlg.querySelector('[data-deadlock-giveup]');
    dlg.showModal();
    const onReshuffle = () => { dlg.close(); cleanup(); resolve('reshuffle'); };
    const onGiveup = () => { dlg.close(); cleanup(); resolve('giveup'); };
    const onCancel = (e) => { e.preventDefault(); /* 阻止 Esc 关闭，强制选择 */ };
    const cleanup = () => {
      reshuffleBtn.removeEventListener('click', onReshuffle);
      giveupBtn.removeEventListener('click', onGiveup);
      dlg.removeEventListener('cancel', onCancel);
    };
    reshuffleBtn.addEventListener('click', onReshuffle, { once: true });
    giveupBtn.addEventListener('click', onGiveup, { once: true });
    dlg.addEventListener('cancel', onCancel);
  });
}

export function showGameOver(deadlockCount) {
  return new Promise((resolve) => {
    const dlg = $('gameOverDialog');
    const desc = $('gameOverDesc');
    const restartBtn = dlg.querySelector('[data-gameover-restart]');
    if (desc) desc.textContent = `本局共出现 ${deadlockCount} 次死局`;
    dlg.showModal();
    const onRestart = () => { dlg.close(); restartBtn.removeEventListener('click', onRestart); resolve(); };
    const onCancel = (e) => { e.preventDefault(); };
    restartBtn.addEventListener('click', onRestart);
    dlg.addEventListener('cancel', onCancel);
    setTimeout(() => restartBtn.focus(), 50);
  });
}
```

- [ ] **Step 2: 浏览器手测**

`game/main.js` 临时写：
```js
import { showWin, showDeadlock, showGameOver } from './dialogs.js';
const w = showWin();
w.onRestart(() => console.log('win restart'));
setTimeout(async () => {
  const r = await showDeadlock();
  console.log('deadlock choice:', r);
  await showGameOver(2);
  console.log('gameover dismissed');
}, 2000);
```
刷新页面，依次确认胜利弹框（带 × 关闭）→ 2 秒后死局弹框（两按钮可选）→ 选择后游戏结束弹框（带次数描述）。Esc 应被阻止。测后清空。

- [ ] **Step 3: Commit**

```bash
git add game/dialogs.js
git commit -m "feat: native dialog wrapper for win/deadlock/gameover flows"
```

---

