### Task 8: interaction.js — 动画 + pitch 动态测量（A6）

**Files:**
- Modify: `game/interaction.js`（替换 `animateMoves` 占位）

覆盖修复：**A6** 用 state.pitch 替代硬编码

- [ ] **Step 1: 替换 animateMoves 实现**

```js
function animateMoves(moves, duration) {
  if (!moves.length) return;
  // 用 state.pitch 计算 dx/dy（A6）
  moves.forEach(m => {
    const el = state.cellEls[m.toR] && state.cellEls[m.toR][m.toC];
    if (!el) return;
    const dx = (m.fromC - m.toC) * state.pitch;
    const dy = (m.fromR - m.toR) * state.pitch;
    el.style.transition = 'none';
    el.style.transform = `translate(${dx}px, ${dy}px)`;
  });
  const first = state.cellEls[moves[0].toR][moves[0].toC];
  void first.offsetWidth;
  requestAnimationFrame(() => {
    moves.forEach(m => {
      const el = state.cellEls[m.toR] && state.cellEls[m.toR][m.toC];
      if (el) {
        el.style.transition = `transform ${duration}ms cubic-bezier(0.34, 1.56, 0.64, 1)`;
        el.style.transform = '';
      }
    });
  });
  setTimeout(() => {
    moves.forEach(m => {
      const el = state.cellEls[m.toR] && state.cellEls[m.toR][m.toC];
      if (el) { el.style.transition = ''; el.style.transform = ''; }
    });
  }, duration + 30);
}
```

- [ ] **Step 2: 浏览器手测**

- DevTools 切到 375px / 768px / 1440px 三档，每档刷新页面后拖动一次
- 动画位移准确（无错位、无 overshoot）
- 改窗口大小后再拖动，位移仍准确（resize 监听已生效）

- [ ] **Step 3: Commit**

```bash
git add game/interaction.js
git commit -m "feat: pitch-aware FLIP animation replacing hardcoded CELL_PX"
```

---

